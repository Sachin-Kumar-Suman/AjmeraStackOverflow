export interface SearchParameter{
    tags: string[];
}
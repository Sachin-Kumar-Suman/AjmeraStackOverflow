export interface SearchResultItem{
    title: string;
    tags: string;
    isAnswered: boolean;
    lastActivity: string;
}
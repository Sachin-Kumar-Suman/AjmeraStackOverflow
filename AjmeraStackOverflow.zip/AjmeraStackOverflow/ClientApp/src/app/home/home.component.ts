import { Component } from '@angular/core';
import { SearchParameter } from '../models/searchParameter.model';
import { SearchResultItem } from '../models/SearchResultItem.model';
import { FetchDataService } from '../services/fetchData.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  searchClicked: boolean;
  searchText: string;
  searchResult: SearchResultItem[] = [];

  constructor(private fetchDataService: FetchDataService){
    this.searchClicked = true;
  }

  fetchData(){
    this.searchClicked = true;
    let body: SearchParameter;
    body.tags = [this.searchText];
    this.fetchDataService.fetchData(body).subscribe(
      data =>{
        this.searchResult.push(data);
      },
      error =>{
        // handle error here
      }
    );
  }
}

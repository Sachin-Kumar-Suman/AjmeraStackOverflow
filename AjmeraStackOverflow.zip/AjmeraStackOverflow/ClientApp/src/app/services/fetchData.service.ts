import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { SearchParameter } from "../models/searchParameter.model";
import { SearchResultItem } from "../models/SearchResultItem.model";

@Injectable()
export class FetchDataService{
    constructor(private client: HttpClient){}
    
    fetchData(body: SearchParameter): Observable<SearchResultItem> {
        return this.client.post<SearchResultItem>('/api/Search', body);
    }
}
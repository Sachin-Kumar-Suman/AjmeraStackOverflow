using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AjmeraStackoverflow.Models;
using AjmeraStackoverflow.Services;
using Microsoft.AspNetCore.Mvc;

namespace AjmeraStackoverflow.Controllers
{
    [Route("api/[controller]")]
    public class SearchController : Controller
    {
        SearchService searchService;
        public SearchController(SearchService service)
        {
            searchService = service;
        }

        [HttpPost]
        [Route("Search")]
        public List<SearchresultItem> Search([FromBody] SearchParameter parameters)
        {
            try
            {
                return searchService.Search(parameters);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }        
    }
}

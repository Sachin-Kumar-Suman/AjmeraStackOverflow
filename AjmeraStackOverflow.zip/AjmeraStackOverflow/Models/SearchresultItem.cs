﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AjmeraStackoverflow.Models
{
    public class SearchresultItem
    {
        public string title { get; set; }
        public string[] tags { get; set; }
        public string isAnswered { get; set; }
        public string lastActivity { get; set; }
    }
}

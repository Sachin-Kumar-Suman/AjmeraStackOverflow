﻿using AjmeraStackoverflow.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace AjmeraStackoverflow.Services
{
    public class SearchService
    {
        private string url;
        public SearchService()
        {
            url = "https://api.stackexchange.com/docs/advanced-search#order=desc&sort=activity&q=react&filter=default&site=stackoverflow&run=true";
        }

        public List<SearchresultItem> Search(SearchParameter parameters)
        {
            using( var client = new HttpClient())
            {
                url += "&tagged=" + parameters.tags;
                var result = client.GetAsync(url);

                if (result.Result.StatusCode == System.Net.HttpStatusCode.OK)
                {                    
                    var responseString =  result.Result.Content.ReadAsStringAsync().Result;
                    return CreateSearchresultList(responseString);
                }
                else
                {
                    return null;
                }
            }
        }

        private List<SearchresultItem> CreateSearchresultList(string response)
        {
            JObject json = JObject.Parse(response);
            List<SearchresultItem> searchResultItems = new List<SearchresultItem>();
            foreach(var item in json["items"])
            {
                SearchresultItem searchResult = new SearchresultItem();
                if(item["title"] != null)
                    searchResult.title = (item["title"]).ToString();

                if (item["is_answered"] != null)
                    searchResult.isAnswered = (item["is_answered"]).ToString();

                if (item["last_activity_date"] != null)
                    searchResult.lastActivity = (item["last_activity_date"]).ToString();

                if (item["tags"] != null)
                {
                    foreach(var tag in item["tags"])
                    {
                        searchResult.tags.Append(tag.ToString());
                    }
                }

                searchResultItems.Add(searchResult);
            }

            return searchResultItems;
        }
    }
}
